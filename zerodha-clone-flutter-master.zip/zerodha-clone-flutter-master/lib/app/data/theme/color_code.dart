import 'package:flutter/material.dart';

const primary = Colors.blueAccent;
