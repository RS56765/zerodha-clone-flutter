package com.treding.treding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
